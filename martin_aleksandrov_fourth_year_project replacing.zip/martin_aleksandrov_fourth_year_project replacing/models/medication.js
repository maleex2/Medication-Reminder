
class Med {
    constructor(id, title, form, strength, strengthValue, quantity, quantityValue, alarm1, alarm2, alarm3, reason, instructions) {
        this.id = id;
        this.title = title;
        this.form = form;
        this.strength = strength;
        this.strengthValue = strengthValue;
        this.quantity = quantity;
        this.quantityValue = quantityValue;
        this.alarm1 = alarm1;
        this.alarm2 = alarm2;
        this.alarm3 = alarm3;
        this.reason = reason;
        this.instructions = instructions;
    }
}

export default Med;