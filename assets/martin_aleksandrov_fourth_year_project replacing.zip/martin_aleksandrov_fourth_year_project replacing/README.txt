To test the application on a real mobile device:


Easier way:
Please download the application Expo Go from Google play or the app store.
Log in with theese details:
	username: maleex2
	password: 123a456b
You will be shown 2 published projects projects, please press on the one called Medication Reminder.



To run and test the application on a pc, you will need an emulator provided by XCode or Android Dev Studio.
For android studio, create a emulator with x86 system.

In terminal, cd into the project dirctory and run
npm install
to isntall dependecies. After that run
expo start 
to start the deployment server.
You can then connect to the emulator from the interface or by pressin a for android and i for ios.
